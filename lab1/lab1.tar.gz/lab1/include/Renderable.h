#ifndef RENDERABLE_H
#define RENDERABLE_H
#include <iostream> 

class Renderable
{
    public:

    virtual void draw() const
    {
        std::cout << "Drawing Renderable" << std::endl; 
    }

    virtual ~Renderable(){}


};


#endif